#include <iostream>
using namespace std;

int main() {
float length,breadth,area;
cout<< "Enter the length of rectangle=";
cin>>length;
cout<< "Enter the breadth of rectangle=";
cin>>breadth;
area=(length*breadth);
cout<<"area of rectangle ="<<area;
	return 0;
}