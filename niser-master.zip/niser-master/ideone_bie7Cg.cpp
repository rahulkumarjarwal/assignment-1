#include <iostream>
using namespace std;

int main() {
	float x,y,s,d,m,d1;
	 cout<<"enter two numbers:";
	 cin>>x>>y;
	 cout<<"add the numbers";
	 s=x+y;
	 cout<<"sum of these two numbers="<<s; 
	 cout<<"substract the second number from the first number";
	 d=x-y;
	 cout<<"difference of these two numbers="<<d;
	  cout<<"multiply the numbers";
	 m=x*y;
	 cout<<"multiplication of these two numbers="<<m; 
	  cout<<"divide the first number by the second number";
	 d1=x/y;
	 cout<<"division of these two numbers="<<d1;
	return 0;
}