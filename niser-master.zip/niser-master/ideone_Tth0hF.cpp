#include <iostream>
using namespace std;

int main() {
float a,b,s;
cout<< "Enter two numbers:";
cin>>a>>b;
s=a+b;
cout<<s;

	return 0;
}