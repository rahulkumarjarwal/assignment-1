#include <iostream>
using namespace std;

int main() {
float r,d,p,a;
cout<<"enter the radius of the circle=";
cin>>r;
cout<<"diameter of the circle=";
d=2*r;
cout<<"diameter of the circle="<<d;
cout<<"perimeter of the circle=";
p=2*3.14159265358979*r;
cout<<"perimeter of the circle="<<p;
cout<<"area of the circle=";
a=3.14159265358979*r*r;
cout<<"area of the circle="<<a;
	return 0;
}