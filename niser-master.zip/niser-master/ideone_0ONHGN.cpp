#include <iostream>
using namespace std;

int main() {
int a;
bool b;
char c;
double d;
long e;
cout<<"enter the value of the int";
cin>>a;
cout<<"integer value="<<a;
cout<<"enter the value of the bool";
cin>>b;
cout<<"bool value="<<b;
cout<<"enter the value of the char";
cin>>c;
cout<<"char value="<<c;
cout<<"enter the value of the double";
cin>>d;
cout<<"double value="<<d;
cout<<"enter the value of the long";
cin>>e;
cout<<"long value="<<e;
	return 0;
}