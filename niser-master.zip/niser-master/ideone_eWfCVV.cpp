#include <iostream>
using namespace std;

int main() {
	float length,breadth,perimeter;
cout<< "Enter the length of rectangle=";
cin>>length;
cout<< "Enter the breadth of rectangle=";
cin>>breadth;
perimeter=2*(length+breadth);
cout<<"perimeter of rectangle ="<<perimeter;
	return 0;
}